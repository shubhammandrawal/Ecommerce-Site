'use strict';

/**
 * best-seller controller
 */

const { createCoreController } = require('@strapi/strapi').factories;

module.exports = createCoreController('api::best-seller.best-seller');
