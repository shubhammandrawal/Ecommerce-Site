import './Banner.css';
export default function Banner(){
    return<div className="banner">
        <img alt='' src="https://img.freepik.com/free-vector/space-game-background-neon-night-alien-landscape_107791-1624.jpg?w=1380&t=st=1687371428~exp=1687372028~hmac=123b45857bbae6871f7bcbfe6d1eb2191eb1c74442eb4d6936321688dea58fd7" />
    </div>
}