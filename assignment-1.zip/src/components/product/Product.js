import './product.css'

export default function Product(){
    return<div>
        <h2>PRODUCTS</h2>
    </div>
}